%Exercice 2

x=linspace(0,5,1000);
y=0.05*x+2.01;
p=3*sin(x.^2)+2*cos(y.^3);
q=3*cos(x.*y);

plot(p);
hold on
plot(q);
plot(y);
hold off
clf

%Exercice 3

e= [-2;2;-2+3i;-2-3i];
p=poly(e);
x=linspace(-5,5,1000);
roots(p);
y=polyval(p,x);
plot(y);
hold on 
plot(e);
hold off
clf

%Exercice 4


t=linspace(0,3,1000);

g=3*exp((-i*2*pi.*t)+(pi/4));
r=real(g);
im1=imag(g);



plot(r);
hold all
plot(im1);

l=abs(r);
%l2=abs(i);


p=angle(g);
%p2=angle(im1);
plot(p);
%plot(p2);
%plot(l2);
plot(l);
hold off
clf

%Exercice 5

e=blackbox(9,5);

%Exercice 6 

x=0:0.001:3;
e=sin(x*2*pi*5);
v=size(e)
plot(x,e)
xlabel('longeur du signal'(num2str(v)))
ylabel('Temps(s)')
grid on
title('Sinusoide de fr�quence 5HZ')

