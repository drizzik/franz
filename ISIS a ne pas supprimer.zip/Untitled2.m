%Exercice 2

x=linspace(0,5,1000);
y=0.05*x+2.01;
p=3*sin(x.^2)+2*cos(y.^3);
q=3*cos(x.*y);

plot(p);
hold on
plot(q);
plot(y);
hold off
clf

%Exercice 3

e= [-2;2;-2+3i;-2-3i];
p=poly(e);
x=linspace(-5,5,1000);
roots(p);
y=polyval(p,x);
plot(y);
hold on 
plot(e);
hold off
clf

%Exercice 4


t=linspace(0,3,1000);

g=3*exp((-i*2*pi.*t)+(pi/4));
r=real(g);
i=imag(g);


plot(r);
hold on
plot(i);

%l=abs(g);

%p=angle(g);
%plot(p);
%hold off


