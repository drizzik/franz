function [res] = blackbox(c,d)
g=c+1
p=d.*2

res=p.*g
end
